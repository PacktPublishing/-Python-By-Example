'''
Created on Mai 2, 2018
@author: Burkhard A. Meier
'''






# duck typing fails - different objects do NOT have the same methods

class Cathedral():
    def build(self):
        print('building a cathedral...')
        
    def visit(self):
        print('Welcome to our Cathedral')


class Cafe():
    def build(self):
        print('building a cafe...')
    
    def visit(self):
        print('Welcome to our Cafe')
        

class Car():
    def build(self):
        print('building a car...')
        
        
def create(building):                       
    building.build()
    building.visit()                        # AttributeError: 'Car' object has no attribute 'visit'


notre_dame = Cathedral()    
java_house = Cafe()
car = Car()

things = notre_dame, java_house, car

for the_thing in (things):
    create(the_thing)
    print()






