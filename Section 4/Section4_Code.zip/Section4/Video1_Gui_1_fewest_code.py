'''
Created on May 7, 2018
@author: Burkhard A. Meier
'''






import tkinter
tkinter.Tk().mainloop()





























