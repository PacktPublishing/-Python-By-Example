
class MyClass3():
    
    def __init__(self):
        print('Hello from', __class__)

if __name__ == '__main__':
    MyClass3()
