'''
Created on May 12, 2018
@author: Burkhard A. Meier
'''





import os

cwd = os.getcwd()
print(cwd)

module_dir = os.path.dirname(__file__)
print(module_dir)

















